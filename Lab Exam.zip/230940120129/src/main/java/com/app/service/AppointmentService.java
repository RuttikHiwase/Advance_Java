
package com.app.service;

import com.app.pojos.Appointment;

public interface AppointmentService {
    Appointment scheduleAppointment(Appointment appointment);
    List<Appointment> getUpcomingAppointmentsByUserId(Long userId);
    void cancelAppointment(Long appointmentId);
}


