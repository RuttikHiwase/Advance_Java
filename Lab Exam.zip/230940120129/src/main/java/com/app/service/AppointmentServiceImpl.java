
package com.app.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppointmentServiceImpl implements AppointmentService {

 @Autowired
 private AppointmentRepository appointmentRepository;

 @Override
 public Appointment scheduleAppointment(Appointment appointment) {
     return appointmentRepository.save(appointment);
 }

 @Override
 public List<Appointment> getUpcomingAppointmentsByUserId(Long userId) {
     LocalDate today = LocalDate.now();
     return appointmentRepository.findByUserIdAndDateAfter(userId, today);
 }

 @Override
 public void cancelAppointment(Long appointmentId) {
     appointmentRepository.deleteById(appointmentId);
 }
}
