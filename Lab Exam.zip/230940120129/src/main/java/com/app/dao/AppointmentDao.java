package com.app.dao;

import java.time.LocalDate;
import java.util.List; 

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByPatientName(String patientName);
    List<Appointment> findByDateAfterAndPatientName(LocalDate date, String patientName);
}
